package com.example.lock2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
