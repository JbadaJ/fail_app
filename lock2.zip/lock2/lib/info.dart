import 'package:flutter/material.dart';

class Info extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Page'),
      ),
      body: Center(
        child: Text(
          '아직 개발 중입니다.',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
