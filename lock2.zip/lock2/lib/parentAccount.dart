import 'package:flutter/material.dart';

class ParentAccount extends StatefulWidget {
  const ParentAccount({Key? key}) : super(key: key);

  @override
  _ParentAccountState createState() => _ParentAccountState();
}

class _ParentAccountState extends State<ParentAccount> {
  String _text = '자녀의 핸드폰과 연결하여 핸드폰 이용시간을 확인합니다';
  String _buttonText = '연동번호 입력하기';

  void _updateText() {
    setState(() {
      _text = '연동중인 사용자 목록';
      _buttonText = '사용자 A';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(
          child: Text('부모계정'),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 10),
            Text(
              _text,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 32),
            Center(
              child: ElevatedButton(
                onPressed: _updateText,
                child: Text(_buttonText),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
