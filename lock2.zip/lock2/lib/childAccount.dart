import 'package:flutter/material.dart';

class Child extends StatefulWidget {
  const Child({super.key});

  @override
  _ChildState createState() => _ChildState();
}

class _ChildState extends State<Child> {
  String _text = '부모님의 핸드폰에 계정을 연결시킵니다';
  String _buttonText = '연동번호 입력하기';

  void _updateText() {
    setState(() {
      _text = '현재 핸드폰 잠금 관리중 입니다\n(잠금 해제 가능,부모계정으로 연락이 갑니다)';
      _buttonText = '잠금 제어';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(
          child: Text('자녀계정'),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 10),
            Text(
              _text,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 32),
            Center(
              child: ElevatedButton(
                onPressed: _updateText,
                child: Text(_buttonText),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
