import 'package:flutter/material.dart';

class InfoList extends StatelessWidget {
  const InfoList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('금일 앱 사용분석'),
      ),
      body: ListView(
        children: [
          _buildListItem(
            image: 'image/google.png',
            name: '앱이름',
            subtitle: '사용시간',
            description: '사용자가 입력 가능한 곳',
          ),
          _buildListItem(
            image: 'image/google.png',
            name: 'Name 2',
            subtitle: 'Subtitle 2',
            description: 'Description 2',
          ),
          _buildListItem(
            image: 'image/google.png',
            name: 'Name 3',
            subtitle: 'Subtitle 3',
            description: 'Description 3',
          ),
          _buildListItem(
            image: 'image/google.png',
            name: 'Name 4',
            subtitle: 'Subtitle 4',
            description: 'Description 4',
          ),
          // 아래에 추가로 텍스트 추가 가능
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              '금일 사용시간 표시',
              style: TextStyle(fontSize: 16),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              '월 평균 사용시간',
              style: TextStyle(fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildListItem({
    required String image,
    required String name,
    required String subtitle,
    required String description,
  }) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: ListTile(
        leading: Image.asset(
          image,
          width: 80, // 이미지의 가로 크기
          height: 80, // 이미지의 세로 크기
          fit: BoxFit.cover, // 이미지가 유지되도록 설정
        ),
        title: Text(name),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(subtitle),
            Text(
              description,
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: InfoList(),
  ));
}
