import 'package:flutter/material.dart';

class Sole extends StatefulWidget {
  const Sole({super.key});

  @override
  _SoleState createState() => _SoleState();
}

class _SoleState extends State<Sole> {
  String _text = '스스로 핸드폰 이용시간을 관리합니다';
  String _buttonText = '연동번호 입력하기';

  void _updateText() {
    setState(() {
      _text = '현재 잠금해제 상태입니다';
      _buttonText = '잠금 시작하기';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(
          child: Text('개인계정'),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 10),
            Text(
              _text,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 32),
            Center(
              child: ElevatedButton(
                onPressed: _updateText,
                child: Text(_buttonText),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
