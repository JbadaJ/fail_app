import 'package:flutter/material.dart';
import 'parentAccount.dart';
import 'childAccount.dart'; // Import the separated Child widget
import 'soleAccount.dart';


class Network extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text('사용자 선택')),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
            width: 200,
            height: 50,
            child:
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ParentAccount()),
                );
              },
              child: const Text('부모계정'),
            ),
            ),
            const SizedBox(height: 5),
        SizedBox(
          width: 200,
          height: 50,
          child:
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Child()),
                );
              },
              child: const Text('자녀계정'),
            ),
        ),
            const SizedBox(height: 5),
        SizedBox(
          width: 200,
          height: 50,
          child:
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Sole()),
                );
              },
              child: const Text('개인계정'),
            ),
        ),
          ],
        ),
      ),
    );
  }
}

