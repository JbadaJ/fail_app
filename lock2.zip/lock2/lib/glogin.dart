/*
개발중 오류때문에 취소된 코드입니다. 구글 로그인 기능으로 잦은 오류때문에 코드를 사용하지 않았습니다.
*/

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

class Glogin extends StatefulWidget{
  const Glogin({super.key});

  @override
  State<Glogin> createState() => _GloginState();
}

class _GloginState extends State<Glogin>{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: SafeArea(
          child: Column(
        crossAxisAlignment:  CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                  onTap: (){
                    signInWithGoogle();
                  },
                  child: Card(
                    margin: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(7)),
                    elevation: 2,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset('image/google.png'),
                        const SizedBox(width: 10,),
                        const Text("Sign in With Google,",
                            style:TextStyle(color: Colors.grey, fontSize: 17)
                        )],
                  ),
                )
                )]))
        ],
      ))
    );
  }

  Future<UserCredential> signInWithGoogle() async {
    // Trigger the authentication flow
    final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

    // Obtain the auth details from the request
    final GoogleSignInAuthentication? googleAuth = await googleUser?.authentication;

    // Create a new credential
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth?.accessToken,
      idToken: googleAuth?.idToken,
    );

    // Once signed in, return the UserCredential
    return await FirebaseAuth.instance.signInWithCredential(credential);
  }
}