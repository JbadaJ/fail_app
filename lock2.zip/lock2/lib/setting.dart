import 'package:flutter/material.dart';
import 'info.dart';

class Setting extends StatefulWidget {
  const Setting({Key? key}) : super(key: key);

  @override
  _SettingState createState() => _SettingState();
}

class _SettingState extends State<Setting> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('설정'),
      ),
      body: ListView.builder(
        itemCount: 6,
        itemBuilder: (context, index) {
          String message = '';
          switch (index) {
            case 0:
              message = '설정';
              break;
            case 1:
              message = '버전 정보';
              break;
            case 2:
              message = '고객 센터';
              break;
            case 3:
              message = '약관 및 개정';
              break;
            case 4:
              message = '개발 정보';
              break;
            case 5:
              message = '공지 사항';
              break;
          }
          return ListTile(
            title: Text(message),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Info()),
              );
            },
          );
        },
      ),
    );
  }
}
